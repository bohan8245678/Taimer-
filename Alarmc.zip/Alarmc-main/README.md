# Alarmc
Alarm clock application source code for my youtube tutorial video:
https://youtu.be/PUvQd0XHwdI
